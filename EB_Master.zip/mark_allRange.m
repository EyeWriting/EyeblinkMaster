% range���� ��� display�Ѵ�.
%----------------------------------------------------------------------
% by Won-Du Chang, ph.D, 
% Research Professor @  Department of Biomedical Engineering, Hanyang University
% contact: 12cross@gmail.com
%---------------------------------------------------------------------
function mark_allRange(range_data, color,handle_axis)
    nRange = size(range_data,1);
    if nRange<1 
        return;
    end
    yrange = get(handle_axis,'YLim');
    x = zeros(nRange*4,1 );
    y_default = zeros(nRange*4,1 );
    

    for i=1:nRange
        x( (i-1)*4+1: i*4) = [ range_data(i,1); range_data(i,1); range_data(i,2); range_data(i,2)];
        y_default( (i-1)*4+1: i*4) = [0;1;1;0];
    end
   
    hold(handle_axis,'on') ;
  
    y = y_default.*yrange(1);
    handle_allHighlight = area(handle_axis,x, y);
    set(handle_allHighlight,'EdgeColor','none');
    set(handle_allHighlight,'FaceColor',color);
    
    set(get(handle_allHighlight,'children'),'FaceAlpha',0.5);
    if yrange(1)*yrange(2)<0
        y = y_default.*yrange(2);
        handle_allHighlight = area(handle_axis,x, y);
        set(handle_allHighlight,'EdgeColor','none');
        set(handle_allHighlight,'FaceColor',color);
        set(get(handle_allHighlight,'children'),'FaceAlpha',0.5);
    end
    hold(handle_axis,'off') ;
end