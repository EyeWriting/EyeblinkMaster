% Eyeblink ������ �׽�Ʈ�ϱ� ���� �Լ�
%----------------------------------------------------------------------
% by Won-Du Chang, ph.D, 
% Research Professor @  Department of Biomedical Engineering, Hanyang University
% contact: 12cross@gmail.com
%---------------------------------------------------------------------
addpath('./automaticThresholding');
addpath('./datastructure');
addpath('./SimpleMath');

load('sample.txt')
d = sample(1:32:length(sample),:); %resampling to 64Hz

%[ range , threshold] = detectblink(d); %if you want to determine threshold automatic
[ range] = detectblink_withThreshold(d,220);


%drawing
figure
plot(d,'color',[0 0 1]);
hold on;
mark_allRange(range,[1,1,0],gca)
hold on;
plot(d,'color',[0 0 1]);
hold off;